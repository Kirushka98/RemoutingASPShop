﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Obj;

namespace Asp
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        UObj obj;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Ent_Click(object sender, EventArgs e)
        {
            using (obj = new UObj())
            {
                string a = Pass.Value;

                if (obj.Enter_serv(Login.Text, a))
                    Response.Redirect("WebForm3.aspx");
                else Login.Text = "нельзя";
            }
        }
    }
}