﻿using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Remoting.Activation;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Obj;


namespace Asp
{
    public partial class WebForm1 : System.Web.UI.Page
    {
       Obj.UObj obj;
        ILease lease;

        public WebForm1()
        {
            
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
       

        protected void Arend_Click(object sender, EventArgs e)
        {
            using (obj = new UObj())
            {
                txt.Text = obj.Prihod(Convert.ToString(this.type_serv.SelectedItem), this.Cal.SelectedDate);
                if (txt.Text == null) txt.Text = "сервера кончились, подождите";
            }

        }

        protected void buy_Click(object sender, EventArgs e)
        {
            using (obj = new UObj())
            {
                txt.Text = obj.Uhod(Convert.ToString(this.type_serv.SelectedItem));
                if (txt.Text == null) txt.Text = "сервера кончились, подождите";
            }
        }
    }
    
   
}